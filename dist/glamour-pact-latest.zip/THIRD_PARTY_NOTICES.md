# Third-party notices

## Final Fantasy XIV job icons

Job icon textures are owned by Square Enix. Crystal Job Rank does not copy or
redistribute them; the plugin requests the icons at runtime from the user's
installed game files through Dalamud's texture service. The rank frames and
job-themed ornament drawing code in this repository are original to this
project.

The non-shipping art-direction board at
`assets/concepts/job-rank-upgrades.png` was generated with OpenAI image
generation. It is a visual design reference, not a source of the runtime job
icons.

## Glamour Pact control art

The shipping `glamour-pact-control-icons.png` atlas was generated with OpenAI
image generation from user-provided Final Fantasy XIV character screenshots
and then locally converted to a transparent UI asset. It does not extract or
redistribute Square Enix game textures or third-party mod files.

## Project GagSpeak experimental control interoperability

The optional, experimental forced-follow and pose-lock services were
conceptually adapted and substantially rewritten from Project GagSpeak's
movement and emote detours at commit
`2e0e3ee8f2f5b680d698181b129dcc21c6bdfab3` (release 2.1.3.2):

- Project: https://github.com/Project-GagSpeak/client
- License: Apache License 2.0
- Adapted areas: input-state gates, mouse-movement suppression, unfollow
  interception, exact hard-target pinning, and `AgentEmote.ExecuteEmote`
  interception

The Glamour Pact versions are modified files: they use maintained
FFXIVClientStructs pointers where available, validate every required native
address before activation, pin the exact paired actor, release on unsafe game
states, and fail closed without autonomous retargeting or command retry loops.
GagSpeak's source comments also credit HybridCamera for its historical
mouse-movement research.

A complete copy of the Apache License 2.0 is distributed at
`licenses/Project-GagSpeak-APACHE-2.0.txt`.

## Snowcloak / Mare Glamourer lock interoperability

Glamour Pact recognizes the standard sync-client Glamourer lock key only to
open, keep briefly editable, and read the exact visible paired actor selected
by the user. Its bounded editing lease never tries an unknown or foreign key.
The interoperability constant and its unlock/apply contract were verified against
Snowcloak's public `IpcCallerGlamourer` implementation at commit
`b061d1ae3435089ee3ffd579bc46f94e68e6d96a`:

- https://github.com/Eauldane/SnowcloakClient/blob/b061d1ae3435089ee3ffd579bc46f94e68e6d96a/Snowcloak/Interop/Ipc/IpcCallerGlamourer.cs

No Snowcloak source code or binaries are distributed with Glamour Pact.

## PvP Tracker interoperability research

The Crystalline Conflict result-packet layout and the current match-end hook
signature were researched and cross-checked against:

- PvP Tracker / PvpStats by SaMo (`wrath16/PvpStats`)
- Source: https://github.com/wrath16/PvpStats
- License: MIT

No PvP Tracker UI, database, timeline, action parser, or live-combat code is
included. The packet declaration in this repository is a small, independently
structured interoperability boundary containing offsets required to read the
game's post-match payload.

The upstream repository publishes the following license notice verbatim:

> MIT License
>
> Copyright (c) [year] [fullname]
>
> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to deal
> in the Software without restriction, including without limitation the rights
> to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
> copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all
> copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.

## Glamourer.Api and Penumbra.Api

The optional Glamour Pact plugin redistributes the official IPC wrapper
packages by Ottermandias:

- `Glamourer.Api.dll` 2.8.2 — https://github.com/Ottermandias/Glamourer.Api
- `Penumbra.Api.dll` 5.15.1 — https://github.com/Ottermandias/Penumbra.Api
- Packages: https://www.nuget.org/packages/Glamourer.Api/2.8.2 and
  https://www.nuget.org/packages/Penumbra.Api/5.15.1
- Both licenses: MIT

Copyright (c) 2025 Ottermandias

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
